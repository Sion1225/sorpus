# sorpus
Sentence OpeRations Processing UtilitieS.
